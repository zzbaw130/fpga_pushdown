SET
Timing is on.
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile enabled for plan 879881912440716 (flags=255)
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile status scan_calls=3 scan_ms=4188.277 flash_read_bytes=1579975720 flash_write_bytes=60171304 input_chunks=47 spill_write_bytes=60171304 spill_read_bytes=60171304 fifo_batches=37 fifo_write_bytes=251659996 fifo_read_bytes=251659996 fdm_reserved_bytes=302006272 operator_memory_bytes=33554432 operator_peak_bytes=29494560 operator_allocations=5 operator_spill_count=4 stream_input_batches=30 stream_input_rows=3231383 stream_input_peak_bytes=7036920 spill_cursor_peak_bytes=0 spill_writer_peak_bytes=0 sort_merge_rows=0 stream_join_calls=2 stream_join_batches=30 stream_join_rows=3231383 stream_join_build_bytes=67805980 stream_join_partitioned_calls=1
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=1 calls=3 rows=914244 elapsed_ms=4188.277
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=3 calls=3 rows=914244 elapsed_ms=0.000
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=4 calls=8 rows=1125139 elapsed_ms=49.836
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=5 calls=2 rows=177079 elapsed_ms=0.000
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=8 calls=1 rows=11272 elapsed_ms=0.000
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=10 calls=1 rows=11272 elapsed_ms=5.943
 l_orderkey |   revenue   | o_orderdate | o_shippriority 
------------+-------------+-------------+----------------
     885895 | 428442.5359 | 1995-03-26  |              0
    4207744 | 392122.0251 | 1995-03-26  |              0
    5660420 | 389343.1796 | 1995-03-08  |              0
    3837441 | 382568.0383 | 1995-02-14  |              0
    5006400 | 377083.4322 | 1995-03-18  |              0
    1983815 | 373983.2402 | 1995-03-25  |              0
    5583330 | 372972.6217 | 1995-03-28  |              0
    4837957 | 369585.3452 | 1995-02-21  |              0
    2759685 | 368851.5057 | 1995-02-27  |              0
    2500838 | 357224.2910 | 1995-03-18  |              0
(10 rows)

Time: 1973.067 ms (00:01.973)

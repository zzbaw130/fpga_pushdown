SET
Timing is on.
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile enabled for plan 879869029660350 (flags=255)
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile status scan_calls=3 scan_ms=4700.293 flash_read_bytes=1519804416 flash_write_bytes=0 input_chunks=47 spill_write_bytes=0 spill_read_bytes=0 fifo_batches=37 fifo_write_bytes=251659996 fifo_read_bytes=251659996 fdm_reserved_bytes=4294967296 operator_memory_bytes=4026515456 operator_peak_bytes=192086040 operator_allocations=4 operator_spill_count=0 stream_input_batches=1 stream_input_rows=29949 stream_input_peak_bytes=598980 spill_cursor_peak_bytes=0 spill_writer_peak_bytes=0 sort_merge_rows=0 stream_join_calls=1 stream_join_batches=1 stream_join_rows=29949 stream_join_build_bytes=58973200 stream_join_partitioned_calls=0
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=1 calls=3 rows=4085812 elapsed_ms=4700.293
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=3 calls=3 rows=4085812 elapsed_ms=0.002
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=4 calls=8 rows=4296707 elapsed_ms=53.072
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=5 calls=2 rows=177079 elapsed_ms=1232.545
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=8 calls=1 rows=11272 elapsed_ms=0.000
psql:/mnt/cemu/scripts/gen_data/queries/3.sql:27: NOTICE:  CSD profile opcode=10 calls=1 rows=11272 elapsed_ms=6.192
 l_orderkey |   revenue   | o_orderdate | o_shippriority 
------------+-------------+-------------+----------------
     885895 | 428442.5359 | 1995-03-26  |              0
    4207744 | 392122.0251 | 1995-03-26  |              0
    5660420 | 389343.1796 | 1995-03-08  |              0
    3837441 | 382568.0383 | 1995-02-14  |              0
    5006400 | 377083.4322 | 1995-03-18  |              0
    1983815 | 373983.2402 | 1995-03-25  |              0
    5583330 | 372972.6217 | 1995-03-28  |              0
    4837957 | 369585.3452 | 1995-02-21  |              0
    2759685 | 368851.5057 | 1995-02-27  |              0
    2500838 | 357224.2910 | 1995-03-18  |              0
(10 rows)

Time: 1820.451 ms (00:01.820)
